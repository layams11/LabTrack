import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import mongoose from 'mongoose';
import User from '../models/User.js';
import Instrument from '../models/Instrument.js';
import Booking from '../models/Booking.js';
import { initialUsers, initialInstruments, initialBookings } from './seedData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const STORAGE_FILE = path.join(__dirname, 'storage.json');

let isMongoConnected = false;

// In-memory / persistent file cache
let memoryUsers = [];
let memoryInstruments = [];
let memoryBookings = [];

// Load from disk or initialize with seeds
function loadStorage() {
  try {
    if (fs.existsSync(STORAGE_FILE)) {
      const data = JSON.parse(fs.readFileSync(STORAGE_FILE, 'utf-8'));
      memoryUsers = data.users || JSON.parse(JSON.stringify(initialUsers));
      memoryInstruments = data.instruments || JSON.parse(JSON.stringify(initialInstruments));
      memoryBookings = data.bookings || JSON.parse(JSON.stringify(initialBookings));
      console.log(`[Database] Loaded persistent storage: ${memoryUsers.length} users, ${memoryInstruments.length} instruments, ${memoryBookings.length} bookings.`);
      return;
    }
  } catch (err) {
    console.warn('[Database] Failed to read storage file, initializing with defaults:', err.message);
  }

  memoryUsers = JSON.parse(JSON.stringify(initialUsers));
  memoryInstruments = JSON.parse(JSON.stringify(initialInstruments));
  memoryBookings = JSON.parse(JSON.stringify(initialBookings));
  saveStorage();
}

// Save current state to disk
function saveStorage() {
  try {
    const data = {
      users: memoryUsers,
      instruments: memoryInstruments,
      bookings: memoryBookings,
      lastUpdated: new Date().toISOString(),
    };
    fs.writeFileSync(STORAGE_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('[Database] Error saving storage to disk:', err.message);
  }
}

// Initial storage load
loadStorage();

export async function connectDB(mongoUri) {
  const uri = mongoUri || process.env.MONGO_URI || 'mongodb://localhost:27017/scientific_instrument_booking';

  try {
    mongoose.set('strictQuery', false);
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2000,
    });
    isMongoConnected = true;
    console.log(`[Database] MongoDB Connected successfully to: ${uri}`);

    const userCount = await User.countDocuments();
    if (userCount === 0) {
      console.log('[Database] Seeding initial users into MongoDB...');
      await User.insertMany(memoryUsers);
    }

    const instrumentCount = await Instrument.countDocuments();
    if (instrumentCount === 0) {
      console.log('[Database] Seeding initial instruments into MongoDB...');
      await Instrument.insertMany(memoryInstruments);
    }

    const bookingCount = await Booking.countDocuments();
    if (bookingCount === 0) {
      console.log('[Database] Seeding initial bookings into MongoDB...');
      await Booking.insertMany(memoryBookings);
    }
  } catch (error) {
    isMongoConnected = false;
    console.log('[Database] Local MongoDB daemon not reachable. Using file-persistent datastore at server/data/storage.json.');
  }
}

function generateObjectId() {
  const timestamp = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
  const random = Math.floor(Math.random() * 0xffffffffffff).toString(16).padStart(12, '0');
  const counter = Math.floor(Math.random() * 0xffff).toString(16).padStart(4, '0');
  return timestamp + random + counter;
}

export const timeToMinutes = (timeStr) => {
  if (!timeStr || typeof timeStr !== 'string') return 0;
  const parts = timeStr.trim().split(':');
  const hours = parseInt(parts[0], 10) || 0;
  const minutes = parseInt(parts[1], 10) || 0;
  return hours * 60 + minutes;
};

export const dbService = {
  getIsConnected() {
    return isMongoConnected;
  },

  // USER METHODS
  async getUserByEmail(email) {
    const cleanEmail = (email || '').toLowerCase().trim();
    if (isMongoConnected) {
      return await User.findOne({ email: cleanEmail });
    }
    return memoryUsers.find((u) => u.email.toLowerCase() === cleanEmail) || null;
  },

  async getUserById(id) {
    if (isMongoConnected) {
      return await User.findById(id).select('-password');
    }
    const user = memoryUsers.find((u) => String(u._id) === String(id));
    if (!user) return null;
    const { password, ...safeUser } = user;
    return safeUser;
  },

  async createUser({ name, email, password, role = 'user' }) {
    const cleanEmail = email.toLowerCase().trim();
    const cleanName = name.trim();

    if (isMongoConnected) {
      const newUser = new User({
        name: cleanName,
        email: cleanEmail,
        password,
        role,
      });
      const saved = await newUser.save();
      return {
        _id: saved._id,
        name: saved.name,
        email: saved.email,
        role: saved.role,
      };
    }

    const newUser = {
      _id: generateObjectId(),
      name: cleanName,
      email: cleanEmail,
      password,
      role: role === 'admin' ? 'admin' : 'user',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    memoryUsers.push(newUser);
    saveStorage();

    const { password: _, ...safeUser } = newUser;
    return safeUser;
  },

  async getAllUsers() {
    if (isMongoConnected) {
      return await User.find().select('-password').sort({ createdAt: -1 });
    }
    return memoryUsers.map(({ password, ...safe }) => safe);
  },

  // INSTRUMENT METHODS
  async getAllInstruments() {
    if (isMongoConnected) {
      return await Instrument.find().sort({ createdAt: -1 });
    }
    return [...memoryInstruments];
  },

  async getInstrumentById(id) {
    if (isMongoConnected) {
      return await Instrument.findById(id);
    }
    return memoryInstruments.find((item) => String(item._id) === String(id)) || null;
  },

  async createInstrument(data) {
    if (isMongoConnected) {
      const inst = new Instrument(data);
      return await inst.save();
    }
    const newInst = {
      _id: generateObjectId(),
      name: data.name.trim(),
      category: data.category.trim(),
      location: data.location.trim(),
      description: data.description.trim(),
      status: data.status || 'Available',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    memoryInstruments.unshift(newInst);
    saveStorage();
    return newInst;
  },

  async updateInstrument(id, data) {
    if (isMongoConnected) {
      return await Instrument.findByIdAndUpdate(id, data, { new: true, runValidators: true });
    }
    const index = memoryInstruments.findIndex((item) => String(item._id) === String(id));
    if (index === -1) return null;
    memoryInstruments[index] = {
      ...memoryInstruments[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    saveStorage();
    return memoryInstruments[index];
  },

  async deleteInstrument(id) {
    if (isMongoConnected) {
      return await Instrument.findByIdAndDelete(id);
    }
    const index = memoryInstruments.findIndex((item) => String(item._id) === String(id));
    if (index === -1) return null;
    const deleted = memoryInstruments.splice(index, 1);
    memoryBookings = memoryBookings.filter((b) => String(b.instrumentId) !== String(id));
    saveStorage();
    return deleted[0];
  },

  // BOOKING METHODS
  async getAllBookings() {
    if (isMongoConnected) {
      return await Booking.find()
        .populate('userId', 'name email role')
        .populate('instrumentId')
        .sort({ date: -1, startTime: -1 });
    }
    return memoryBookings
      .map((b) => {
        const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
        const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
        return {
          ...b,
          userId: user
            ? { _id: user._id, name: user.name, email: user.email, role: user.role }
            : { _id: b.userId, name: 'User', email: '' },
          instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
        };
      })
      .sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
  },

  async getUserBookings(userId) {
    if (isMongoConnected) {
      return await Booking.find({ userId })
        .populate('userId', 'name email')
        .populate('instrumentId')
        .sort({ date: -1, startTime: -1 });
    }
    return memoryBookings
      .filter((b) => String(b.userId) === String(userId))
      .map((b) => {
        const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
        const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
        return {
          ...b,
          userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
          instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
        };
      })
      .sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
  },

  async getBookingById(id) {
    if (isMongoConnected) {
      return await Booking.findById(id).populate('userId', 'name email').populate('instrumentId');
    }
    const b = memoryBookings.find((item) => String(item._id) === String(id));
    if (!b) return null;
    const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
    const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
    return {
      ...b,
      userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
      instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
    };
  },

  // Check booking conflict:
  // Same instrument, same date, existing booking status is NOT "Cancelled"
  // Overlap condition: newStartTime < existingEndTime AND newEndTime > existingStartTime
  async checkBookingConflict(instrumentId, date, startTime, endTime, excludeBookingId = null) {
    const newStartMins = timeToMinutes(startTime);
    const newEndMins = timeToMinutes(endTime);

    let activeBookings = [];
    if (isMongoConnected) {
      const query = {
        instrumentId,
        date,
        status: { $ne: 'Cancelled' },
      };
      if (excludeBookingId) {
        query._id = { $ne: excludeBookingId };
      }
      activeBookings = await Booking.find(query);
    } else {
      activeBookings = memoryBookings.filter((b) => {
        const matchesInst = String(b.instrumentId) === String(instrumentId);
        const matchesDate = b.date === date;
        const notCancelled = b.status !== 'Cancelled';
        const notExcluded = !excludeBookingId || String(b._id) !== String(excludeBookingId);
        return matchesInst && matchesDate && notCancelled && notExcluded;
      });
    }

    const hasConflict = activeBookings.some((existing) => {
      const existingStartMins = timeToMinutes(existing.startTime);
      const existingEndMins = timeToMinutes(existing.endTime);
      return newStartMins < existingEndMins && newEndMins > existingStartMins;
    });

    return hasConflict;
  },

  // Automatically creates booking with status = "Confirmed"
  async createBooking(data) {
    const bookingPayload = {
      userId: data.userId,
      instrumentId: data.instrumentId,
      date: data.date,
      startTime: data.startTime,
      endTime: data.endTime,
      purpose: data.purpose.trim(),
      status: data.status || 'Confirmed',
      actualStartTime: data.actualStartTime || null,
      actualEndTime: data.actualEndTime || null,
      actualUsageDuration: data.actualUsageDuration || null,
    };

    if (isMongoConnected) {
      const booking = new Booking(bookingPayload);
      const saved = await booking.save();
      return await Booking.findById(saved._id)
        .populate('userId', 'name email')
        .populate('instrumentId');
    }

    const newBooking = {
      _id: generateObjectId(),
      ...bookingPayload,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    memoryBookings.unshift(newBooking);
    saveStorage();

    const user = memoryUsers.find((u) => String(u._id) === String(newBooking.userId));
    const inst = memoryInstruments.find((i) => String(i._id) === String(newBooking.instrumentId));
    return {
      ...newBooking,
      userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
      instrumentId: inst || { _id: newBooking.instrumentId, name: 'Unknown Instrument' },
    };
  },

  // Start Usage: status -> "In Progress", sets actualStartTime, marks equipment as "In Use"
  async startUsage(id) {
    const now = new Date();
    const update = {
      status: 'In Progress',
      actualStartTime: now,
    };

    if (isMongoConnected) {
      const updated = await Booking.findByIdAndUpdate(id, update, { new: true, runValidators: true })
        .populate('userId', 'name email')
        .populate('instrumentId');

      if (updated && updated.instrumentId) {
        const instId = updated.instrumentId._id || updated.instrumentId;
        const currentInst = await Instrument.findById(instId);
        if (currentInst && currentInst.status !== 'Maintenance') {
          await Instrument.findByIdAndUpdate(instId, { status: 'In Use' });
        }
      }
      return updated;
    }

    const index = memoryBookings.findIndex((item) => String(item._id) === String(id));
    if (index === -1) return null;
    memoryBookings[index] = {
      ...memoryBookings[index],
      ...update,
      actualStartTime: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    // Mark instrument as In Use in memory if not in maintenance
    const targetInstId = memoryBookings[index].instrumentId;
    const instIndex = memoryInstruments.findIndex((item) => String(item._id) === String(targetInstId));
    if (instIndex !== -1 && memoryInstruments[instIndex].status !== 'Maintenance') {
      memoryInstruments[instIndex].status = 'In Use';
      memoryInstruments[instIndex].updatedAt = now.toISOString();
    }
    saveStorage();

    const b = memoryBookings[index];
    const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
    const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
    return {
      ...b,
      userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
      instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
    };
  },

  // End Usage: status -> "Completed", sets actualEndTime and calculates actualUsageDuration in minutes, frees equipment
  async endUsage(id) {
    const existing = await this.getBookingById(id);
    if (!existing) return null;

    const endTime = new Date();
    const startTime = existing.actualStartTime ? new Date(existing.actualStartTime) : new Date(Date.now() - 3600000);
    const diffMs = endTime.getTime() - startTime.getTime();
    const durationMinutes = Math.max(1, Math.round(diffMs / (1000 * 60)));

    const update = {
      status: 'Completed',
      actualEndTime: endTime,
      actualUsageDuration: durationMinutes,
    };

    if (isMongoConnected) {
      const updated = await Booking.findByIdAndUpdate(id, update, { new: true, runValidators: true })
        .populate('userId', 'name email')
        .populate('instrumentId');

      if (updated && updated.instrumentId) {
        const instId = updated.instrumentId._id || updated.instrumentId;
        const otherInProgress = await Booking.findOne({
          instrumentId: instId,
          _id: { $ne: id },
          status: 'In Progress',
        });
        if (!otherInProgress) {
          const currentInst = await Instrument.findById(instId);
          if (currentInst && currentInst.status !== 'Maintenance') {
            await Instrument.findByIdAndUpdate(instId, { status: 'Available' });
          }
        }
      }
      return updated;
    }

    const index = memoryBookings.findIndex((item) => String(item._id) === String(id));
    if (index === -1) return null;
    memoryBookings[index] = {
      ...memoryBookings[index],
      status: 'Completed',
      actualEndTime: endTime.toISOString(),
      actualUsageDuration: durationMinutes,
      updatedAt: endTime.toISOString(),
    };

    const targetInstId = memoryBookings[index].instrumentId;
    const otherInProgress = memoryBookings.some(
      (b) => String(b.instrumentId) === String(targetInstId) && String(b._id) !== String(id) && b.status === 'In Progress'
    );
    if (!otherInProgress) {
      const instIndex = memoryInstruments.findIndex((item) => String(item._id) === String(targetInstId));
      if (instIndex !== -1 && memoryInstruments[instIndex].status !== 'Maintenance') {
        memoryInstruments[instIndex].status = 'Available';
        memoryInstruments[instIndex].updatedAt = endTime.toISOString();
      }
    }
    saveStorage();

    const b = memoryBookings[index];
    const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
    const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
    return {
      ...b,
      userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
      instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
    };
  },

  // Cancel Booking (status -> "Cancelled", frees time slot and resets instrument if was in progress)
  async cancelBooking(id) {
    const existing = await this.getBookingById(id);
    const wasInProgress = existing && existing.status === 'In Progress';
    const targetInstId = existing && existing.instrumentId ? (existing.instrumentId._id || existing.instrumentId) : null;

    const update = { status: 'Cancelled' };
    if (isMongoConnected) {
      const updated = await Booking.findByIdAndUpdate(id, update, { new: true, runValidators: true })
        .populate('userId', 'name email')
        .populate('instrumentId');

      if (wasInProgress && targetInstId) {
        const otherInProgress = await Booking.findOne({
          instrumentId: targetInstId,
          _id: { $ne: id },
          status: 'In Progress',
        });
        if (!otherInProgress) {
          const currentInst = await Instrument.findById(targetInstId);
          if (currentInst && currentInst.status !== 'Maintenance') {
            await Instrument.findByIdAndUpdate(targetInstId, { status: 'Available' });
          }
        }
      }
      return updated;
    }

    const index = memoryBookings.findIndex((item) => String(item._id) === String(id));
    if (index === -1) return null;
    memoryBookings[index] = {
      ...memoryBookings[index],
      status: 'Cancelled',
      updatedAt: new Date().toISOString(),
    };

    if (wasInProgress && targetInstId) {
      const otherInProgress = memoryBookings.some(
        (b) => String(b.instrumentId) === String(targetInstId) && String(b._id) !== String(id) && b.status === 'In Progress'
      );
      if (!otherInProgress) {
        const instIndex = memoryInstruments.findIndex((item) => String(item._id) === String(targetInstId));
        if (instIndex !== -1 && memoryInstruments[instIndex].status !== 'Maintenance') {
          memoryInstruments[instIndex].status = 'Available';
          memoryInstruments[instIndex].updatedAt = new Date().toISOString();
        }
      }
    }
    saveStorage();

    const b = memoryBookings[index];
    const user = memoryUsers.find((u) => String(u._id) === String(b.userId));
    const inst = memoryInstruments.find((i) => String(i._id) === String(b.instrumentId));
    return {
      ...b,
      userId: user ? { _id: user._id, name: user.name, email: user.email } : null,
      instrumentId: inst || { _id: b.instrumentId, name: 'Unknown Instrument' },
    };
  },

  async resetSeedData() {
    memoryUsers = JSON.parse(JSON.stringify(initialUsers));
    memoryInstruments = JSON.parse(JSON.stringify(initialInstruments));
    memoryBookings = JSON.parse(JSON.stringify(initialBookings));
    saveStorage();

    if (isMongoConnected) {
      await User.deleteMany({});
      await Instrument.deleteMany({});
      await Booking.deleteMany({});
      await User.insertMany(initialUsers);
      await Instrument.insertMany(initialInstruments);
      await Booking.insertMany(initialBookings);
    }
    return { message: 'Database reset to sample state successfully.' };
  },
};
