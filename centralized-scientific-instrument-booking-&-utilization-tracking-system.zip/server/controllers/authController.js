import bcrypt from 'bcryptjs';
import { dbService } from '../data/store.js';

// @desc    Register a new user
// @route   POST /api/auth/signup
export const signupUser = async (req, res) => {
  try {
    const { name, email, password, role = 'user' } = req.body;

    // Validation
    if (!name || !name.trim()) {
      return res.status(400).json({ message: 'Full name is required.' });
    }
    if (name.trim().length < 2) {
      return res.status(400).json({ message: 'Name must be at least 2 characters long.' });
    }

    if (!email || !email.trim()) {
      return res.status(400).json({ message: 'Email address is required.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ message: 'Please provide a valid email format (e.g. name@university.edu).' });
    }

    if (!password) {
      return res.status(400).json({ message: 'Password is required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters long.' });
    }

    // Check if user already exists
    const existingUser = await dbService.getUserByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        message: 'An account with this email address already exists. Please log in instead.',
      });
    }

    // Securely hash password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Allowed roles
    const assignedRole = role === 'admin' ? 'admin' : 'user';

    const newUser = await dbService.createUser({
      name: name.trim(),
      email: email.trim(),
      password: hashedPassword,
      role: assignedRole,
    });

    res.status(201).json({
      message: 'Account created successfully! Welcome to LabTrack Central.',
      token: String(newUser._id),
      user: {
        _id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
      },
    });
  } catch (error) {
    console.error('[Auth Error] Signup failed:', error);
    res.status(500).json({ message: 'Registration failed. Please try again.', error: error.message });
  }
};

// @desc    Authenticate user & return credentials
// @route   POST /api/auth/login
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !email.trim()) {
      return res.status(400).json({ message: 'Email address is required.' });
    }
    if (!password) {
      return res.status(400).json({ message: 'Password is required.' });
    }

    const user = await dbService.getUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password. Please verify your credentials.' });
    }

    // Verify password with bcrypt
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password. Please verify your credentials.' });
    }

    res.status(200).json({
      message: 'Login successful.',
      token: String(user._id),
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('[Auth Error] Login failed:', error);
    res.status(500).json({ message: 'Login failed', error: error.message });
  }
};

// @desc    Get current logged in user
// @route   GET /api/auth/me
export const getCurrentUser = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    res.status(200).json({ user: req.user });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving profile', error: error.message });
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
export const logoutUser = async (req, res) => {
  res.status(200).json({ message: 'Logged out successfully.' });
};
