import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectDB } from './data/store.js';
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import instrumentRoutes from './routes/instrumentRoutes.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Connect Database
connectDB(process.env.MONGO_URI);

// Mount API Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/instruments', instrumentRoutes);

// Health check route
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    project: 'Centralized Scientific Instrument Booking & Utilization Tracking System (2-Role Auth)',
    timestamp: new Date().toISOString(),
  });
});

if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`Scientific Instrument Booking Backend Running`);
    console.log(`Port: http://localhost:${PORT}`);
    console.log(`API Base: http://localhost:${PORT}/api`);
    console.log(`====================================================`);
  });
}

export default app;
