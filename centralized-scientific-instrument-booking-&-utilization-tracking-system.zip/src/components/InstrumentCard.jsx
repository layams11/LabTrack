import React from 'react';
import { Link } from 'react-router-dom';

export default function InstrumentCard({ instrument, onEdit, onDelete }) {
  const isAvailable = instrument.status === 'Available';
  const isInUse = instrument.status === 'In Use';
  const isMaintenance = instrument.status === 'Maintenance';

  const cardStatusClass = isAvailable
    ? 'card-available'
    : isInUse
    ? 'card-in-use'
    : 'card-maintenance';

  const badgeStatusClass = isAvailable
    ? 'status-available'
    : isInUse
    ? 'status-in-use'
    : 'status-maintenance';

  return (
    <div className={`instrument-card ${cardStatusClass}`}>
      <div className="instrument-card-header">
        <div className="instrument-info">
          <h3 className="instrument-name">{instrument.name}</h3>
          <span className="instrument-category-badge">{instrument.category}</span>
        </div>
        <span className={`status-badge ${badgeStatusClass}`}>
          {instrument.status}
        </span>
      </div>

      <div className="instrument-location">
        <span className="location-icon">📍</span>
        <span className="location-text">{instrument.location}</span>
      </div>

      <p className="instrument-description">{instrument.description}</p>

      <div className="instrument-card-actions">
        {!isMaintenance ? (
          <Link
            to={`/book?instrumentId=${instrument._id}`}
            className="btn btn-primary btn-sm"
          >
            📅 Book Instrument
          </Link>
        ) : (
          <button className="btn btn-disabled btn-sm" disabled>
            Under Maintenance
          </button>
        )}

        <div className="secondary-actions">
          {onEdit && (
            <button
              onClick={() => onEdit(instrument)}
              className="btn btn-outline btn-sm"
              title="Edit Instrument"
            >
              ✏️ Edit
            </button>
          )}
          {onDelete && (
            <button
              onClick={() => onDelete(instrument)}
              className="btn btn-danger-outline btn-sm"
              title="Delete Instrument"
            >
              🗑️ Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
