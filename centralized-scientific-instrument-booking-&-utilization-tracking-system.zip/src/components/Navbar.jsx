import React from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, isAuthenticated, isAdmin, isUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <header className="site-header">
      <div className="header-inner">
        <Link
          to={isAdmin ? '/admin/dashboard' : isUser ? '/user/dashboard' : '/login'}
          className="brand-link"
        >
          <div className="brand-mark">🔬</div>
          <div className="brand-info">
            <span className="brand-name">LabTrack</span>
            <span className="brand-portal">
              {isAdmin ? 'Admin Management' : isUser ? 'Research Portal' : 'Scientific Instrument System'}
            </span>
          </div>
        </Link>

        {isAuthenticated && (
          <nav className="header-nav">
            {isUser && (
              <>
                <NavLink
                  to="/user/dashboard"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Dashboard
                </NavLink>
                <NavLink
                  to="/instruments"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Instruments
                </NavLink>
                <NavLink
                  to="/book"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Book Slot
                </NavLink>
                <NavLink
                  to="/my-bookings"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  My Bookings
                </NavLink>
              </>
            )}

            {isAdmin && (
              <>
                <NavLink
                  to="/admin/dashboard"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Dashboard
                </NavLink>
                <NavLink
                  to="/admin/instruments"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Instruments
                </NavLink>
                <NavLink
                  to="/admin/bookings"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Bookings
                </NavLink>
                <NavLink
                  to="/admin/utilization"
                  className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
                >
                  Utilization
                </NavLink>
              </>
            )}
          </nav>
        )}

        <div className="header-actions">
          {isAuthenticated ? (
            <div className="user-profile-bar">
              <div className="user-identity">
                <span className="user-display-name">{user?.name}</span>
                <span className={`user-role-badge badge-${user?.role}`}>
                  {user?.role === 'admin' ? 'Admin' : 'User'}
                </span>
              </div>
              <button
                type="button"
                onClick={handleLogout}
                className="btn btn-outline btn-sm logout-btn"
                title="Securely end current session"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn btn-primary btn-sm">
              Sign In
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
