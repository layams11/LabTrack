import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { formatMinutes } from './AdminBookings';
import ConfirmModal from '../../components/ConfirmModal';

export default function AdminDashboard() {
  const { user, authFetch } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [notification, setNotification] = useState(null);
  const [processingId, setProcessingId] = useState(null);

  // In-app confirmation modal state
  const [modalState, setModalState] = useState({
    isOpen: false,
    type: null, // 'start' | 'end' | 'cancel'
    bookingId: null,
    instrumentName: '',
    userName: '',
    timeSlot: '',
  });

  useEffect(() => {
    fetchAdminDashboard();
  }, []);

  const fetchAdminDashboard = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await authFetch('/api/admin/dashboard');
      if (!res.ok) throw new Error('Failed to load admin dashboard metrics.');
      const resData = await res.json();
      setData(resData);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const promptStartUsage = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'start',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  const promptEndUsage = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'end',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  const promptCancelBooking = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'cancel',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  const closeModal = () => {
    if (processingId) return;
    setModalState({
      isOpen: false,
      type: null,
      bookingId: null,
      instrumentName: '',
      userName: '',
      timeSlot: '',
    });
  };

  const handleConfirmAction = async () => {
    const { type, bookingId, instrumentName } = modalState;
    if (!type || !bookingId) return;

    try {
      setProcessingId(bookingId);

      let endpoint = '';
      if (type === 'start') {
        endpoint = `/api/admin/bookings/${bookingId}/start-usage`;
      } else if (type === 'end') {
        endpoint = `/api/admin/bookings/${bookingId}/end-usage`;
      } else if (type === 'cancel') {
        endpoint = `/api/admin/bookings/${bookingId}/cancel`;
      }

      const res = await authFetch(endpoint, {
        method: 'POST',
      });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.message || `Failed to perform action (${type})`);

      if (type === 'start') {
        setNotification({
          type: 'success',
          text: `Usage started for ${instrumentName}. Booking is now "In Progress" and instrument is in use.`,
        });
      } else if (type === 'end') {
        setNotification({
          type: 'success',
          text: `Usage completed for ${instrumentName}. Actual duration: ${formatMinutes(
            resData.booking?.actualUsageDuration
          )}. Time slot concluded.`,
        });
      } else if (type === 'cancel') {
        setNotification({
          type: 'success',
          text: `Booking cancelled successfully and slot freed for ${instrumentName}.`,
        });
      }

      setTimeout(() => setNotification(null), 5000);
      closeModal();
      await fetchAdminDashboard();
    } catch (err) {
      setNotification({
        type: 'error',
        text: err.message || 'Operation failed. Please try again.',
      });
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="page-shell">
        <div className="state-notice">Loading operations dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-shell">
        <div className="alert-banner alert-banner-error">
          <span>{error}</span>
          <button onClick={fetchAdminDashboard} className="btn btn-outline btn-sm ml-auto">
            Retry
          </button>
        </div>
      </div>
    );
  }

  const {
    totalInstruments = 0,
    availableInstruments = 0,
    maintenanceInstruments = 0,
    totalBookings = 0,
    confirmedBookings = 0,
    inProgressBookings = 0,
    completedBookings = 0,
    cancelledBookings = 0,
    recentBookings = [],
  } = data || {};

  return (
    <div className="page-shell">
      {notification && (
        <div className={`alert-banner alert-banner-${notification.type === 'error' ? 'error' : 'success'}`}>
          <span>{notification.text}</span>
          <button
            type="button"
            onClick={() => setNotification(null)}
            className="alert-close"
          >
            ×
          </button>
        </div>
      )}

      {/* Admin Hero Header */}
      <div className="page-hero">
        <div>
          <div className="admin-status-pill">🛡️ Lab Administrator Control</div>
          <h1 className="hero-heading mt-1">Laboratory Operations &amp; Bookings</h1>
          <p className="hero-subtext">
            Welcome, <strong>{user?.name}</strong> • Real-time slot management, live experiment tracking, and fleet status
          </p>
        </div>
        <div className="hero-actions">
          <Link to="/admin/instruments" className="btn btn-outline">
            Manage Instruments
          </Link>
          <Link to="/admin/bookings" className="btn btn-primary">
            All Bookings ({confirmedBookings} Confirmed)
          </Link>
          <Link to="/admin/utilization" className="btn btn-outline">
            Utilization Metrics
          </Link>
        </div>
      </div>

      {/* Clean 4-Metric Consolidated Row */}
      <div className="metrics-strip">
        <div className="metric-box">
          <span className="metric-label">Equipment Fleet</span>
          <div className="metric-value-row">
            <span className="metric-num">{totalInstruments}</span>
            <span className="metric-denominator">total units</span>
          </div>
          <span className="metric-footnote">
            <span className="text-success font-medium">{availableInstruments} available</span> •{' '}
            <span className="text-warning font-medium">{maintenanceInstruments} maintenance</span>
          </span>
        </div>

        <div className="metric-box">
          <span className="metric-label">Active Slots</span>
          <div className="metric-value-row">
            <span className="metric-num text-primary">{confirmedBookings + inProgressBookings}</span>
            <span className="metric-denominator">pending / running</span>
          </div>
          <span className="metric-footnote">
            {confirmedBookings} confirmed • {inProgressBookings} in progress
          </span>
        </div>

        <div className="metric-box">
          <span className="metric-label">Completed Runs</span>
          <div className="metric-value-row">
            <span className="metric-num text-success">{completedBookings}</span>
            <span className="metric-denominator">completed</span>
          </div>
          <span className="metric-footnote">With tracked actual duration</span>
        </div>

        <div className="metric-box">
          <span className="metric-label">Total Reservations</span>
          <div className="metric-value-row">
            <span className="metric-num">{totalBookings}</span>
            <span className="metric-denominator">all-time</span>
          </div>
          <span className="metric-footnote">{cancelledBookings} cancelled / freed</span>
        </div>
      </div>

      {/* Operations Table Section */}
      <section className="panel-card">
        <div className="panel-header">
          <div>
            <h2 className="panel-title">Recent Laboratory Bookings</h2>
            <p className="panel-desc">Real-time schedule of user bookings with quick operation actions</p>
          </div>
          <Link to="/admin/bookings" className="panel-action-link">
            Manage All Bookings ({totalBookings}) →
          </Link>
        </div>

        {recentBookings.length === 0 ? (
          <div className="empty-state-box">
            <p className="text-muted">No bookings found in the database.</p>
          </div>
        ) : (
          <div className="records-table-wrap">
            <table className="clean-table">
              <thead>
                <tr>
                  <th>Researcher</th>
                  <th>Instrument</th>
                  <th>Date</th>
                  <th>Scheduled Slot</th>
                  <th>Actual Usage</th>
                  <th>Status</th>
                  <th className="text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentBookings.map((b) => {
                  const userName = b.userId?.name || 'Researcher';
                  const userEmail = b.userId?.email || '';
                  const instName = b.instrumentId?.name || 'Instrument';
                  const isProcessing = processingId === b._id;

                  return (
                    <tr key={b._id}>
                      <td>
                        <div className="font-medium text-main">{userName}</div>
                        <div className="text-muted text-xs">{userEmail}</div>
                      </td>
                      <td>
                        <span className="font-medium">{instName}</span>
                      </td>
                      <td className="text-muted">{b.date}</td>
                      <td className="font-mono text-xs">
                        {b.startTime} – {b.endTime}
                      </td>
                      <td>
                        {b.status === 'Completed' && (
                          <span className="font-medium text-primary text-xs">
                            ⏱️ {formatMinutes(b.actualUsageDuration)}
                          </span>
                        )}
                        {b.status === 'In Progress' && (
                          <span className="badge badge-warning text-xs">
                            🟢 Live Run
                          </span>
                        )}
                        {(b.status === 'Confirmed' || b.status === 'Cancelled') && (
                          <span className="text-muted text-xs">—</span>
                        )}
                      </td>
                      <td>
                        <span
                          className={`badge status-${b.status.toLowerCase().replace(' ', '-')}`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="text-right">
                        <div className="inline-action-group">
                          {b.status === 'Confirmed' && (
                            <>
                              <button
                                onClick={() =>
                                  promptStartUsage(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-primary btn-xs"
                                disabled={isProcessing}
                                title="Start live experiment run"
                              >
                                {isProcessing ? 'Updating...' : 'Start Usage'}
                              </button>
                              <button
                                onClick={() =>
                                  promptCancelBooking(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-outline btn-xs btn-danger-text"
                                disabled={isProcessing}
                                title="Cancel booking"
                              >
                                Cancel
                              </button>
                            </>
                          )}
                          {b.status === 'In Progress' && (
                            <>
                              <button
                                onClick={() =>
                                  promptEndUsage(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-success btn-xs"
                                disabled={isProcessing}
                                title="Stop and log actual runtime"
                              >
                                {isProcessing ? 'Updating...' : 'End Usage'}
                              </button>
                              <button
                                onClick={() =>
                                  promptCancelBooking(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-outline btn-xs btn-danger-text"
                                disabled={isProcessing}
                                title="Cancel booking"
                              >
                                Cancel
                              </button>
                            </>
                          )}
                          {(b.status === 'Completed' || b.status === 'Cancelled') && (
                            <span className="text-muted text-xs">—</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* In-app Confirmation Modal (Iframe-safe, zero window.confirm blocking) */}
      <ConfirmModal
        isOpen={modalState.isOpen}
        title={
          modalState.type === 'start'
            ? 'Start Instrument Usage'
            : modalState.type === 'end'
            ? 'End Instrument Usage'
            : 'Cancel Reservation'
        }
        message={
          modalState.type === 'start'
            ? `Start active laboratory experiment session for "${modalState.instrumentName}"?`
            : modalState.type === 'end'
            ? `End active session and record actual usage duration for "${modalState.instrumentName}"?`
            : `Cancel reservation for "${modalState.instrumentName}"?`
        }
        detail={
          modalState.type === 'start' ? (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This marks the booking as "In Progress", starts live session tracking, and sets the instrument as "In Use".
              </span>
            </div>
          ) : modalState.type === 'end' ? (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This logs the exact elapsed usage duration, marks the booking as "Completed", and returns the instrument to "Available".
              </span>
            </div>
          ) : (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This cancels the booking and frees up the scheduled date and time slot for new reservations.
              </span>
            </div>
          )
        }
        confirmText={
          modalState.type === 'start'
            ? 'Start Usage'
            : modalState.type === 'end'
            ? 'End Usage'
            : 'Cancel Booking'
        }
        confirmVariant={
          modalState.type === 'start'
            ? 'primary'
            : modalState.type === 'end'
            ? 'success'
            : 'danger'
        }
        onConfirm={handleConfirmAction}
        onCancel={closeModal}
        loading={!!processingId}
      />
    </div>
  );
}
