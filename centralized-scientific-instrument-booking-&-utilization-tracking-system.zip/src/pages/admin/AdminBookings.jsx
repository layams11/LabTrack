import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import ConfirmModal from '../../components/ConfirmModal';

// Helper to format minutes into human readable "1 hr 34 min"
export function formatMinutes(mins) {
  if (mins === null || mins === undefined || isNaN(mins)) return '—';
  const total = Math.round(mins);
  const hours = Math.floor(total / 60);
  const minutes = total % 60;

  if (hours === 0) return `${minutes} min`;
  if (minutes === 0) return `${hours} hr`;
  return `${hours} hr ${minutes} min`;
}

// Helper to calculate scheduled duration from startTime and endTime
export function calculateScheduledDuration(startTime, endTime) {
  if (!startTime || !endTime) return '—';
  const [sH, sM] = startTime.split(':').map(Number);
  const [eH, eM] = endTime.split(':').map(Number);
  const diffMinutes = Math.max(0, eH * 60 + eM - (sH * 60 + sM));
  return formatMinutes(diffMinutes);
}

export default function AdminBookings() {
  const { authFetch } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState(null);
  const [processingId, setProcessingId] = useState(null);

  // In-app confirmation dialog state
  const [modalState, setModalState] = useState({
    isOpen: false,
    type: null, // 'start' | 'end' | 'cancel'
    bookingId: null,
    instrumentName: '',
    userName: '',
    timeSlot: '',
  });

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await authFetch('/api/admin/bookings');
      if (!res.ok) throw new Error('Failed to load laboratory bookings.');
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Open confirmation modal for Start Usage
  const promptStartUsage = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'start',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  // Open confirmation modal for End Usage
  const promptEndUsage = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'end',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  // Open confirmation modal for Cancel Booking
  const promptCancelBooking = (bookingId, instrumentName, userName, timeSlot) => {
    setModalState({
      isOpen: true,
      type: 'cancel',
      bookingId,
      instrumentName,
      userName,
      timeSlot,
    });
  };

  // Close modal
  const closeModal = () => {
    if (processingId) return;
    setModalState({
      isOpen: false,
      type: null,
      bookingId: null,
      instrumentName: '',
      userName: '',
      timeSlot: '',
    });
  };

  // Execute confirmed action
  const handleConfirmAction = async () => {
    const { type, bookingId, instrumentName } = modalState;
    if (!type || !bookingId) return;

    try {
      setProcessingId(bookingId);

      let endpoint = '';
      if (type === 'start') {
        endpoint = `/api/admin/bookings/${bookingId}/start-usage`;
      } else if (type === 'end') {
        endpoint = `/api/admin/bookings/${bookingId}/end-usage`;
      } else if (type === 'cancel') {
        endpoint = `/api/admin/bookings/${bookingId}/cancel`;
      }

      const res = await authFetch(endpoint, {
        method: 'POST',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || `Failed to perform action (${type}).`);

      if (type === 'start') {
        setNotification({
          type: 'success',
          text: `Usage started for ${instrumentName}. Status is now "In Progress" and instrument is in use.`,
        });
      } else if (type === 'end') {
        setNotification({
          type: 'success',
          text: `Usage ended for ${instrumentName}. Recorded actual duration: ${formatMinutes(
            data.booking?.actualUsageDuration
          )}. Status: "Completed".`,
        });
      } else if (type === 'cancel') {
        setNotification({
          type: 'success',
          text: `Booking cancelled and time slot released for ${instrumentName}.`,
        });
      }

      setTimeout(() => setNotification(null), 5000);
      closeModal();
      await fetchBookings();
    } catch (err) {
      setNotification({ type: 'error', text: err.message });
    } finally {
      setProcessingId(null);
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Confirmed':
        return 'status-badge status-approved';
      case 'In Progress':
        return 'status-badge status-in-progress';
      case 'Completed':
        return 'status-badge status-completed';
      case 'Cancelled':
        return 'status-badge status-cancelled';
      default:
        return 'status-badge';
    }
  };

  const filtered = bookings.filter((b) => {
    if (statusFilter !== 'ALL' && b.status !== statusFilter) return false;

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const userName = (b.userId?.name || '').toLowerCase();
      const userEmail = (b.userId?.email || '').toLowerCase();
      const instName = (b.instrumentId?.name || '').toLowerCase();
      const purpose = (b.purpose || '').toLowerCase();

      return (
        userName.includes(term) ||
        userEmail.includes(term) ||
        instName.includes(term) ||
        purpose.includes(term)
      );
    }
    return true;
  });

  const confirmedCount = bookings.filter((b) => b.status === 'Confirmed').length;
  const inProgressCount = bookings.filter((b) => b.status === 'In Progress').length;
  const completedCount = bookings.filter((b) => b.status === 'Completed').length;
  const cancelledCount = bookings.filter((b) => b.status === 'Cancelled').length;

  return (
    <div className="page-container">
      <div className="page-header-flex">
        <div>
          <h1 className="page-title">Manage Laboratory Bookings &amp; Usage</h1>
          <p className="page-subtitle">
            Track scheduled vs actual instrument usage runtimes, start/end lab sessions, and manage reservations
          </p>
        </div>
        <button onClick={fetchBookings} className="btn btn-outline btn-sm">
          🔄 Refresh
        </button>
      </div>

      {notification && (
        <div className={`alert-box alert-${notification.type}`}>
          <span>{notification.text}</span>
          <button onClick={() => setNotification(null)} className="alert-close">
            ×
          </button>
        </div>
      )}

      {error && (
        <div className="alert-box alert-error">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="alert-close">
            ×
          </button>
        </div>
      )}

      {/* Filter Tabs and Search Bar */}
      <div className="filter-and-search-container">
        <div className="status-tabs">
          <button
            className={`tab-btn ${statusFilter === 'ALL' ? 'active' : ''}`}
            onClick={() => setStatusFilter('ALL')}
          >
            All ({bookings.length})
          </button>
          <button
            className={`tab-btn ${statusFilter === 'Confirmed' ? 'active' : ''}`}
            onClick={() => setStatusFilter('Confirmed')}
          >
            Confirmed ({confirmedCount})
          </button>
          <button
            className={`tab-btn ${statusFilter === 'In Progress' ? 'active' : ''}`}
            onClick={() => setStatusFilter('In Progress')}
          >
            In Progress ({inProgressCount})
          </button>
          <button
            className={`tab-btn ${statusFilter === 'Completed' ? 'active' : ''}`}
            onClick={() => setStatusFilter('Completed')}
          >
            Completed ({completedCount})
          </button>
          <button
            className={`tab-btn ${statusFilter === 'Cancelled' ? 'active' : ''}`}
            onClick={() => setStatusFilter('Cancelled')}
          >
            Cancelled ({cancelledCount})
          </button>
        </div>

        <div className="search-input-wrapper">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            className="search-input"
            placeholder="Search by student, email, or equipment..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="search-clear-btn"
              type="button"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Admin Booking Table (Section 9) */}
      {loading ? (
        <div className="loading-state">Loading bookings schedule...</div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">No matching reservations found.</div>
      ) : (
        <div className="table-card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Instrument</th>
                  <th>Date</th>
                  <th>Scheduled Time</th>
                  <th>Actual Usage</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((b) => {
                  const userName = b.userId?.name || 'Student';
                  const userEmail = b.userId?.email || 'N/A';
                  const instName = b.instrumentId?.name || 'Instrument';

                  const scheduledDurationText = calculateScheduledDuration(
                    b.startTime,
                    b.endTime
                  );
                  const isProcessing = processingId === b._id;

                  return (
                    <tr key={b._id} className={`booking-row-${b.status.toLowerCase().replace(' ', '-')}`}>
                      <td>
                        <div className="font-semibold">{userName}</div>
                        <div className="text-muted text-xs">{userEmail}</div>
                      </td>
                      <td>
                        <span className="instrument-table-name">{instName}</span>
                      </td>
                      <td>{b.date}</td>
                      <td className="time-cell">
                        <div>{b.startTime} - {b.endTime}</div>
                        <div className="text-muted text-xs">({scheduledDurationText})</div>
                      </td>
                      <td>
                        {b.status === 'Completed' && (
                          <span className="actual-usage-badge font-bold text-primary">
                            ⏱️ {formatMinutes(b.actualUsageDuration)}
                          </span>
                        )}
                        {b.status === 'In Progress' && (
                          <span className="actual-usage-running text-warning font-semibold">
                            🟢 Running...
                          </span>
                        )}
                        {(b.status === 'Confirmed' || b.status === 'Cancelled') && (
                          <span className="text-muted text-xs">—</span>
                        )}
                      </td>
                      <td>
                        <span className={getStatusBadgeClass(b.status)}>{b.status}</span>
                      </td>
                      <td>
                        <div className="action-buttons-group">
                          {/* If Confirmed: [ Start Usage ] [ Cancel ] */}
                          {b.status === 'Confirmed' && (
                            <>
                              <button
                                onClick={() =>
                                  promptStartUsage(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-primary btn-xs"
                                disabled={isProcessing}
                                title="Click when user begins using the equipment"
                              >
                                {isProcessing && processingId === b._id ? 'Updating...' : '▶ Start Usage'}
                              </button>
                              <button
                                onClick={() =>
                                  promptCancelBooking(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-danger-outline btn-xs"
                                disabled={isProcessing}
                                title="Cancel booking and free the slot"
                              >
                                Cancel
                              </button>
                            </>
                          )}

                          {/* If In Progress: [ End Usage ] [ Cancel ] */}
                          {b.status === 'In Progress' && (
                            <>
                              <button
                                onClick={() =>
                                  promptEndUsage(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-success-outline btn-xs"
                                disabled={isProcessing}
                                title="Click when user finishes experiment to record actual duration"
                              >
                                {isProcessing && processingId === b._id ? 'Updating...' : '⏹ End Usage'}
                              </button>
                              <button
                                onClick={() =>
                                  promptCancelBooking(
                                    b._id,
                                    instName,
                                    userName,
                                    `${b.date} (${b.startTime} - ${b.endTime})`
                                  )
                                }
                                className="btn btn-danger-outline btn-xs"
                                disabled={isProcessing}
                                title="Cancel booking"
                              >
                                Cancel
                              </button>
                            </>
                          )}

                          {/* If Completed or Cancelled: No start/end buttons */}
                          {b.status === 'Completed' && (
                            <span className="text-success text-xs font-semibold">✓ Completed</span>
                          )}
                          {b.status === 'Cancelled' && (
                            <span className="text-muted text-xs">Cancelled</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* In-app Confirmation Modal (Iframe-safe, no blocked native alerts) */}
      <ConfirmModal
        isOpen={modalState.isOpen}
        title={
          modalState.type === 'start'
            ? 'Start Instrument Usage'
            : modalState.type === 'end'
            ? 'End Instrument Usage'
            : 'Cancel Reservation'
        }
        message={
          modalState.type === 'start'
            ? `Start active laboratory experiment session for "${modalState.instrumentName}"?`
            : modalState.type === 'end'
            ? `End active session and record actual usage duration for "${modalState.instrumentName}"?`
            : `Cancel reservation for "${modalState.instrumentName}"?`
        }
        detail={
          modalState.type === 'start' ? (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This records the actual start time, sets the booking status to "In Progress", and marks the instrument as "In Use".
              </span>
            </div>
          ) : modalState.type === 'end' ? (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This records the end time, computes the exact usage duration, sets booking status to "Completed", and frees the instrument.
              </span>
            </div>
          ) : (
            <div>
              <strong>Researcher:</strong> {modalState.userName}
              <br />
              <strong>Scheduled Slot:</strong> {modalState.timeSlot}
              <br />
              <span className="text-muted text-xs">
                This marks the booking as "Cancelled" and immediately frees up the date and time slot for new bookings.
              </span>
            </div>
          )
        }
        confirmText={
          modalState.type === 'start'
            ? 'Start Usage'
            : modalState.type === 'end'
            ? 'End Usage'
            : 'Cancel Booking'
        }
        confirmVariant={
          modalState.type === 'start'
            ? 'primary'
            : modalState.type === 'end'
            ? 'success'
            : 'danger'
        }
        onConfirm={handleConfirmAction}
        onCancel={closeModal}
        loading={!!processingId}
      />
    </div>
  );
}
