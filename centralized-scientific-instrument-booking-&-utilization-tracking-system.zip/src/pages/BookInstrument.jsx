import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function BookInstrument() {
  const [searchParams] = useSearchParams();
  const { user, authFetch } = useAuth();

  const urlInstrumentId = searchParams.get('instrumentId') || '';
  const urlDate = searchParams.get('date') || new Date().toISOString().split('T')[0];
  const urlStartTime = searchParams.get('startTime') || '10:00';
  const urlEndTime = searchParams.get('endTime') || '12:00';

  const [instruments, setInstruments] = useState([]);
  const [loadingInstruments, setLoadingInstruments] = useState(true);

  // Form State
  const [formData, setFormData] = useState({
    instrumentId: urlInstrumentId,
    date: urlDate,
    startTime: urlStartTime,
    endTime: urlEndTime,
    purpose: '',
  });

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);
  const [successInfo, setSuccessInfo] = useState(null);

  // Availability Pre-check state
  const [availabilityStatus, setAvailabilityStatus] = useState(null);
  const [checkingAvailability, setCheckingAvailability] = useState(false);

  // Popup Modal state for conflicting slot
  const [conflictPopup, setConflictPopup] = useState(null);

  // Existing schedule for selected instrument & date
  const [existingSchedule, setExistingSchedule] = useState([]);
  const [loadingSchedule, setLoadingSchedule] = useState(false);

  useEffect(() => {
    fetchInstruments();
  }, []);

  useEffect(() => {
    if (urlInstrumentId) {
      setFormData((prev) => ({
        ...prev,
        instrumentId: urlInstrumentId,
        date: urlDate,
        startTime: urlStartTime,
        endTime: urlEndTime,
      }));
    }
  }, [urlInstrumentId, urlDate, urlStartTime, urlEndTime]);

  useEffect(() => {
    if (formData.instrumentId && formData.date) {
      fetchExistingSchedule(formData.instrumentId, formData.date);
      setAvailabilityStatus(null);
    }
  }, [formData.instrumentId, formData.date]);

  const fetchInstruments = async () => {
    try {
      setLoadingInstruments(true);
      const res = await fetch('/api/instruments');
      const data = await res.json();
      setInstruments(data);
      if (!formData.instrumentId && data.length > 0) {
        const firstAvailable = data.find((i) => i.status === 'Available') || data[0];
        setFormData((prev) => ({ ...prev, instrumentId: firstAvailable._id }));
      }
    } catch (err) {
      console.error(err);
      setFormError('Failed to load instruments list.');
    } finally {
      setLoadingInstruments(false);
    }
  };

  const fetchExistingSchedule = async (instId, date) => {
    try {
      setLoadingSchedule(true);
      const res = await authFetch(`/api/user/instrument-schedule/${instId}/${date}`);
      if (res.ok) {
        const slots = await res.json();
        setExistingSchedule(slots);
      }
    } catch (err) {
      console.error('Error fetching schedule:', err);
    } finally {
      setLoadingSchedule(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setAvailabilityStatus(null);
    if (formError) setFormError(null);
  };

  const handlePreCheck = async () => {
    if (!formData.instrumentId || !formData.date || !formData.startTime || !formData.endTime) {
      setFormError('Please select instrument, date, start time, and end time.');
      return;
    }

    try {
      setCheckingAvailability(true);
      setFormError(null);
      const res = await authFetch('/api/user/check-availability', {
        method: 'POST',
        body: JSON.stringify({
          instrumentId: formData.instrumentId,
          date: formData.date,
          startTime: formData.startTime,
          endTime: formData.endTime,
        }),
      });
      const data = await res.json();
      setAvailabilityStatus(data);
    } catch (err) {
      setFormError(err.message || 'Availability check failed.');
    } finally {
      setCheckingAvailability(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);
    setSuccessInfo(null);
    setConflictPopup(null);

    if (!formData.instrumentId) {
      setFormError('Please select a scientific instrument.');
      return;
    }
    if (!formData.date) {
      setFormError('Date is required.');
      return;
    }
    if (!formData.startTime || !formData.endTime) {
      setFormError('Start time and end time are required.');
      return;
    }

    const [sH, sM] = formData.startTime.split(':').map(Number);
    const [eH, eM] = formData.endTime.split(':').map(Number);
    const startMins = sH * 60 + sM;
    const endMins = eH * 60 + eM;

    if (endMins <= startMins) {
      setFormError('End time must be later than start time.');
      return;
    }

    if (!formData.purpose.trim()) {
      setFormError('Purpose of booking is required.');
      return;
    }

    try {
      setSubmitting(true);
      const res = await authFetch('/api/user/bookings', {
        method: 'POST',
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      // If conflicting slot (HTTP 409 Conflict)
      if (res.status === 409) {
        setConflictPopup({
          title: 'Slot Not Available',
          message: data.message || 'This instrument is already booked during the selected time.',
        });
        return;
      }

      if (!res.ok) {
        throw new Error(data.message || 'Unable to complete reservation.');
      }

      // Automatic Confirmation
      setSuccessInfo({
        message: 'Booking confirmed successfully.',
        booking: data.booking,
      });

      setFormData((prev) => ({
        ...prev,
        purpose: '',
      }));
      setAvailabilityStatus(null);

      fetchExistingSchedule(formData.instrumentId, formData.date);
    } catch (err) {
      setFormError(err.message || 'Booking submission failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const selectedInstrument = instruments.find((i) => i._id === formData.instrumentId);

  return (
    <div className="page-shell">
      {/* Page Header */}
      <div className="page-hero">
        <div>
          <h1 className="hero-heading">Reserve Scientific Equipment</h1>
          <p className="hero-subtext">
            Automatic confirmation with real-time overlap prevention • Booked by <strong>{user?.name}</strong>
          </p>
        </div>
        <div className="hero-actions">
          <Link to="/my-bookings" className="btn btn-outline">
            View My Bookings
          </Link>
        </div>
      </div>

      {/* Conflict Modal Popup */}
      {conflictPopup && (
        <div className="modal-overlay" onClick={() => setConflictPopup(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header-icon">⚠️</div>
            <h2 className="modal-title">{conflictPopup.title}</h2>
            <p className="modal-message">{conflictPopup.message}</p>
            <div className="modal-actions">
              <button
                type="button"
                className="btn btn-primary btn-block"
                onClick={() => setConflictPopup(null)}
              >
                Choose Another Date or Time
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Banner */}
      {successInfo && (
        <div className="alert-banner alert-banner-success">
          <div className="alert-content">
            <span className="font-bold">✓ {successInfo.message}</span>
            <p className="text-xs mt-1">
              Confirmed slot for <strong>{selectedInstrument?.name}</strong> on{' '}
              <strong>{successInfo.booking?.date}</strong> ({successInfo.booking?.startTime} –{' '}
              {successInfo.booking?.endTime}).
            </p>
          </div>
          <div className="alert-actions-inline">
            <Link to="/my-bookings" className="btn btn-outline btn-xs">
              Go to My Bookings
            </Link>
            <button
              onClick={() => setSuccessInfo(null)}
              className="btn btn-primary btn-xs"
            >
              Book Another
            </button>
          </div>
        </div>
      )}

      {/* Error banner */}
      {formError && (
        <div className="alert-banner alert-banner-error">
          <span className="alert-icon">⚠️</span>
          <span>{formError}</span>
        </div>
      )}

      {/* Two-Column Booking Layout */}
      <div className="content-columns">
        {/* Reservation Form */}
        <section className="panel-card flex-2">
          <div className="panel-header">
            <div>
              <h2 className="panel-title">Reservation Details</h2>
              <p className="panel-desc">Select instrument, date, and time slot</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="reservation-form">
            <div className="form-group">
              <label htmlFor="instrumentId" className="form-label">
                Scientific Instrument
              </label>
              {loadingInstruments ? (
                <div className="state-notice text-xs">Loading available instruments...</div>
              ) : (
                <select
                  id="instrumentId"
                  name="instrumentId"
                  className="form-select"
                  value={formData.instrumentId}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">-- Choose an Instrument --</option>
                  {instruments.map((inst) => (
                    <option
                      key={inst._id}
                      value={inst._id}
                      disabled={inst.status === 'Maintenance'}
                    >
                      {inst.name} ({inst.category}) — {inst.location}{' '}
                      {inst.status === 'Maintenance' ? '[Maintenance]' : '[Available]'}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="form-row-three">
              <div className="form-group">
                <label htmlFor="date" className="form-label">
                  Date
                </label>
                <input
                  type="date"
                  id="date"
                  name="date"
                  className="form-input"
                  value={formData.date}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="startTime" className="form-label">
                  Start Time
                </label>
                <input
                  type="time"
                  id="startTime"
                  name="startTime"
                  className="form-input"
                  value={formData.startTime}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="endTime" className="form-label">
                  End Time
                </label>
                <input
                  type="time"
                  id="endTime"
                  name="endTime"
                  className="form-input"
                  value={formData.endTime}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>

            {/* Quick Slot Pre-Check Button */}
            <div className="inline-check-strip">
              <button
                type="button"
                onClick={handlePreCheck}
                className="btn btn-outline btn-sm"
                disabled={checkingAvailability}
              >
                {checkingAvailability ? 'Checking...' : 'Pre-check Slot Availability'}
              </button>

              {availabilityStatus && (
                <span
                  className={`badge ${
                    availabilityStatus.available ? 'badge-success' : 'badge-danger'
                  }`}
                >
                  {availabilityStatus.available ? '✓ Slot Available' : '✕ Slot Occupied'}
                </span>
              )}
            </div>

            <div className="form-group mt-3">
              <label htmlFor="purpose" className="form-label">
                Research Purpose / Sample Analysis
              </label>
              <textarea
                id="purpose"
                name="purpose"
                rows={3}
                className="form-textarea"
                value={formData.purpose}
                onChange={handleInputChange}
                placeholder="Brief description of research experiment, sample run, or coursework analysis..."
                required
              />
            </div>

            <div className="form-footer-action mt-4">
              <button
                type="submit"
                className="btn btn-primary btn-block btn-lg"
                disabled={
                  submitting ||
                  (selectedInstrument && selectedInstrument.status === 'Maintenance')
                }
              >
                {submitting ? 'Confirming Reservation...' : 'Confirm Booking'}
              </button>
            </div>
          </form>
        </section>

        {/* Schedule & Availability Guidance Sidebar */}
        <aside className="panel-card flex-1">
          <div className="panel-header">
            <div>
              <h2 className="panel-title">Existing Bookings</h2>
              <p className="panel-desc">Slots reserved for {formData.date}</p>
            </div>
          </div>

          {selectedInstrument && (
            <div className="instrument-quick-info mb-4">
              <div className="font-semibold text-main">{selectedInstrument.name}</div>
              <div className="text-xs text-muted mt-0.5">
                Location: {selectedInstrument.location} • Category: {selectedInstrument.category}
              </div>
              <div className="mt-1">
                <span
                  className={`badge ${
                    selectedInstrument.status === 'Available' ? 'badge-success' : 'badge-warning'
                  }`}
                >
                  {selectedInstrument.status}
                </span>
              </div>
            </div>
          )}

          <div className="slots-preview-wrap">
            <h3 className="slots-preview-title">Reserved Times for Selected Date:</h3>

            {loadingSchedule ? (
              <div className="state-notice text-xs">Checking daily schedule...</div>
            ) : existingSchedule.length === 0 ? (
              <div className="open-slots-notice">
                ✓ No other bookings on this date. Full schedule is open!
              </div>
            ) : (
              <div className="slot-pill-list">
                {existingSchedule.map((slot, idx) => (
                  <div key={idx} className="slot-pill-item">
                    <span className="font-mono text-xs font-semibold">
                      🕒 {slot.startTime} – {slot.endTime}
                    </span>
                    <span className="badge badge-subtle text-xs">
                      {slot.status}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rule-note-box mt-4">
            <div className="font-semibold text-xs text-main">Conflict Policy:</div>
            <p className="text-xs text-muted mt-1">
              Bookings cannot overlap with existing confirmed runs. Consecutive bookings (e.g. 10:00–12:00 and 12:00–14:00) are permitted.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
