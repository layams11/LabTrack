import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [authMode, setAuthMode] = useState('login'); // 'login' | 'signup'
  const [role, setRole] = useState('user'); // 'user' | 'admin'

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Status
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const handleModeSwitch = (mode) => {
    setAuthMode(mode);
    setError(null);
    setSuccess(null);
  };

  const handleFillDemo = (demoRole) => {
    setAuthMode('login');
    setRole(demoRole);
    if (demoRole === 'admin') {
      setEmail('admin@lab.edu');
      setPassword('admin123');
    } else {
      setEmail('user@lab.edu');
      setPassword('user123');
    }
    setError(null);
    setSuccess(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    // Validation
    const trimmedEmail = email.trim().toLowerCase();
    if (!trimmedEmail) {
      setError('Please provide a valid email address.');
      return;
    }

    if (!password) {
      setError('Please provide your password.');
      return;
    }

    if (authMode === 'signup') {
      if (!name.trim()) {
        setError('Please enter your full name.');
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match. Please re-enter.');
        return;
      }
    }

    try {
      setSubmitting(true);

      if (authMode === 'login') {
        const loggedUser = await login(trimmedEmail, password);
        if (loggedUser.role === 'admin') {
          navigate('/admin/dashboard');
        } else {
          navigate('/user/dashboard');
        }
      } else {
        const newUser = await signup(name.trim(), trimmedEmail, password, role);
        setSuccess('Account created successfully! Redirecting...');
        setTimeout(() => {
          if (newUser.role === 'admin') {
            navigate('/admin/dashboard');
          } else {
            navigate('/user/dashboard');
          }
        }, 600);
      }
    } catch (err) {
      setError(err.message || 'Authentication failed. Please verify your details.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        {/* Brand Header */}
        <div className="auth-header">
          <div className="auth-logo-badge">🔬</div>
          <h1 className="auth-title">LabTrack Central</h1>
          <p className="auth-subtitle">
            Scientific Equipment Reservation &amp; Utilization Management
          </p>
        </div>

        {/* Primary Auth Tabs: Sign In / Create Account */}
        <div className="auth-nav-tabs">
          <button
            type="button"
            className={`auth-nav-btn ${authMode === 'login' ? 'active' : ''}`}
            onClick={() => handleModeSwitch('login')}
          >
            Sign In
          </button>
          <button
            type="button"
            className={`auth-nav-btn ${authMode === 'signup' ? 'active' : ''}`}
            onClick={() => handleModeSwitch('signup')}
          >
            Create Account
          </button>
        </div>

        {/* Portal / Role Toggle */}
        <div className="role-selector-bar">
          <span className="role-selector-label">Access Portal:</span>
          <div className="role-toggle-group">
            <button
              type="button"
              className={`role-toggle-btn ${role === 'user' ? 'active' : ''}`}
              onClick={() => {
                setRole('user');
                setError(null);
              }}
            >
              🎓 Researcher / User
            </button>
            <button
              type="button"
              className={`role-toggle-btn ${role === 'admin' ? 'active' : ''}`}
              onClick={() => {
                setRole('admin');
                setError(null);
              }}
            >
              🛡️ Lab Manager / Admin
            </button>
          </div>
        </div>

        {/* Feedback Alerts */}
        {error && (
          <div className="alert-banner alert-banner-error" role="alert">
            <span className="alert-icon">⚠️</span>
            <span>{error}</span>
          </div>
        )}

        {success && (
          <div className="alert-banner alert-banner-success" role="alert">
            <span className="alert-icon">✓</span>
            <span>{success}</span>
          </div>
        )}

        {/* Dynamic Form */}
        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {authMode === 'signup' && (
            <div className="form-group">
              <label htmlFor="auth-name" className="form-label">
                Full Name
              </label>
              <input
                type="text"
                id="auth-name"
                className="form-input"
                placeholder="Dr. Jane Doe / John Smith"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
          )}

          <div className="form-group">
            <label htmlFor="auth-email" className="form-label">
              {role === 'admin' ? 'Admin Institutional Email' : 'Email Address'}
            </label>
            <input
              type="email"
              id="auth-email"
              className="form-input"
              placeholder={role === 'admin' ? 'admin@lab.edu' : 'researcher@lab.edu'}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="auth-password" className="form-label">
              Password {authMode === 'signup' && <span className="label-hint">(min. 6 chars)</span>}
            </label>
            <input
              type="password"
              id="auth-password"
              className="form-input"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {authMode === 'signup' && (
            <div className="form-group">
              <label htmlFor="auth-confirm-password" className="form-label">
                Confirm Password
              </label>
              <input
                type="password"
                id="auth-confirm-password"
                className="form-input"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary btn-block btn-lg"
            disabled={submitting}
          >
            {submitting ? (
              <span>Authenticating...</span>
            ) : authMode === 'login' ? (
              <span>Sign In to {role === 'admin' ? 'Admin Portal' : 'User Portal'}</span>
            ) : (
              <span>Register as {role === 'admin' ? 'Lab Administrator' : 'Researcher'}</span>
            )}
          </button>
        </form>

        {/* Demo Credentials Footer */}
        <div className="demo-credentials-card">
          <div className="demo-card-header">
            <span className="demo-badge">QUICK TEST</span>
            <span className="demo-hint">Use pre-seeded credentials for instant viva evaluation:</span>
          </div>
          <div className="demo-actions">
            <button
              type="button"
              className="demo-btn"
              onClick={() => handleFillDemo('user')}
            >
              <strong>User:</strong> user@lab.edu / user123
            </button>
            <button
              type="button"
              className="demo-btn"
              onClick={() => handleFillDemo('admin')}
            >
              <strong>Admin:</strong> admin@lab.edu / admin123
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
