import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function UserDashboard() {
  const { user, authFetch } = useAuth();
  const [data, setData] = useState(null);
  const [instruments, setInstruments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Quick Availability Checker State
  const [checkForm, setCheckForm] = useState({
    instrumentId: '',
    date: new Date().toISOString().split('T')[0],
    startTime: '10:00',
    endTime: '12:00',
  });
  const [checkResult, setCheckResult] = useState(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    fetchDashboard();
    fetchInstruments();
  }, []);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await authFetch('/api/user/dashboard');
      if (!res.ok) throw new Error('Failed to load user dashboard.');
      const resData = await res.json();
      setData(resData);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchInstruments = async () => {
    try {
      const res = await fetch('/api/instruments');
      if (res.ok) {
        const insts = await res.json();
        setInstruments(insts);
        if (insts.length > 0 && !checkForm.instrumentId) {
          const firstAvail = insts.find((i) => i.status === 'Available') || insts[0];
          setCheckForm((prev) => ({ ...prev, instrumentId: firstAvail._id }));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCheckAvailability = async (e) => {
    e.preventDefault();
    setCheckResult(null);

    if (!checkForm.instrumentId || !checkForm.date || !checkForm.startTime || !checkForm.endTime) {
      setCheckResult({ available: false, message: 'Please specify instrument, date, and times.' });
      return;
    }

    try {
      setChecking(true);
      const res = await authFetch('/api/user/check-availability', {
        method: 'POST',
        body: JSON.stringify(checkForm),
      });
      const result = await res.json();
      setCheckResult(result);
    } catch (err) {
      setCheckResult({ available: false, message: err.message || 'Availability check failed.' });
    } finally {
      setChecking(false);
    }
  };

  if (loading) {
    return (
      <div className="page-shell">
        <div className="state-notice">Loading dashboard...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-shell">
        <div className="alert-banner alert-banner-error">
          <span>{error}</span>
          <button onClick={fetchDashboard} className="btn btn-outline btn-sm ml-auto">
            Retry
          </button>
        </div>
      </div>
    );
  }

  const {
    availableInstrumentsCount = 0,
    unavailableInstrumentsCount = 0,
    activeBookingsCount = 0,
    completedBookingsCount = 0,
    recentBookings = [],
  } = data || {};

  const totalInstruments = availableInstrumentsCount + unavailableInstrumentsCount;

  return (
    <div className="page-shell">
      {/* Header bar */}
      <div className="page-hero">
        <div>
          <h1 className="hero-heading">Welcome back, {user?.name}</h1>
          <p className="hero-subtext">
            Researcher Laboratory Portal • Real-time slot reservation &amp; session status
          </p>
        </div>
        <div className="hero-actions">
          <Link to="/instruments" className="btn btn-outline">
            Browse Instruments
          </Link>
          <Link to="/book" className="btn btn-primary">
            + Book an Instrument
          </Link>
          <Link to="/my-bookings" className="btn btn-outline">
            My Bookings
          </Link>
        </div>
      </div>

      {/* Clean 3-Metric Summary Bar */}
      <div className="metrics-strip">
        <div className="metric-box">
          <span className="metric-label">Available Equipment</span>
          <div className="metric-value-row">
            <span className="metric-num text-success">{availableInstrumentsCount}</span>
            <span className="metric-denominator">/ {totalInstruments} active</span>
          </div>
          <span className="metric-footnote">
            {unavailableInstrumentsCount > 0
              ? `${unavailableInstrumentsCount} under maintenance`
              : 'All systems online'}
          </span>
        </div>

        <div className="metric-box">
          <span className="metric-label">Active Bookings</span>
          <div className="metric-value-row">
            <span className="metric-num text-primary">{activeBookingsCount}</span>
            <span className="metric-denominator">slots</span>
          </div>
          <span className="metric-footnote">Confirmed or running experiments</span>
        </div>

        <div className="metric-box">
          <span className="metric-label">Completed Sessions</span>
          <div className="metric-value-row">
            <span className="metric-num">{completedBookingsCount}</span>
            <span className="metric-denominator">completed</span>
          </div>
          <span className="metric-footnote">Logged laboratory runtime</span>
        </div>
      </div>

      {/* Main 2-Column Section */}
      <div className="content-columns">
        {/* Left Column: Recent Bookings */}
        <section className="panel-card flex-2">
          <div className="panel-header">
            <div>
              <h2 className="panel-title">My Recent Bookings</h2>
              <p className="panel-desc">Your active and previous laboratory reservations</p>
            </div>
            <Link to="/my-bookings" className="panel-action-link">
              View All ({recentBookings.length}) →
            </Link>
          </div>

          {recentBookings.length === 0 ? (
            <div className="empty-state-box">
              <p className="text-muted">You have no recorded bookings yet.</p>
              <Link to="/book" className="btn btn-primary btn-sm mt-3">
                Reserve Equipment
              </Link>
            </div>
          ) : (
            <div className="records-table-wrap">
              <table className="clean-table">
                <thead>
                  <tr>
                    <th>Instrument</th>
                    <th>Date</th>
                    <th>Time Slot</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentBookings.map((b) => {
                    const instName =
                      typeof b.instrumentId === 'object' && b.instrumentId !== null
                        ? b.instrumentId.name
                        : 'Instrument';

                    return (
                      <tr key={b._id}>
                        <td className="font-medium text-main">{instName}</td>
                        <td className="text-muted">{b.date}</td>
                        <td className="font-mono text-xs">
                          {b.startTime} – {b.endTime}
                        </td>
                        <td>
                          <span
                            className={`badge status-${b.status.toLowerCase().replace(' ', '-')}`}
                          >
                            {b.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Right Column: Inline Availability Checker */}
        <section className="panel-card flex-1">
          <div className="panel-header">
            <div>
              <h2 className="panel-title">Check Availability</h2>
              <p className="panel-desc">Check if a slot is open before booking</p>
            </div>
          </div>

          <form onSubmit={handleCheckAvailability} className="checker-form">
            <div className="form-group">
              <label htmlFor="chk-inst" className="form-label">
                Scientific Instrument
              </label>
              <select
                id="chk-inst"
                className="form-select"
                value={checkForm.instrumentId}
                onChange={(e) =>
                  setCheckForm({ ...checkForm, instrumentId: e.target.value })
                }
                required
              >
                {instruments.map((inst) => (
                  <option key={inst._id} value={inst._id}>
                    {inst.name} {inst.status !== 'Available' ? `(${inst.status})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="chk-date" className="form-label">
                Date
              </label>
              <input
                type="date"
                id="chk-date"
                className="form-input"
                value={checkForm.date}
                onChange={(e) => setCheckForm({ ...checkForm, date: e.target.value })}
                required
              />
            </div>

            <div className="form-row-two">
              <div className="form-group">
                <label htmlFor="chk-start" className="form-label">
                  Start Time
                </label>
                <input
                  type="time"
                  id="chk-start"
                  className="form-input"
                  value={checkForm.startTime}
                  onChange={(e) =>
                    setCheckForm({ ...checkForm, startTime: e.target.value })
                  }
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="chk-end" className="form-label">
                  End Time
                </label>
                <input
                  type="time"
                  id="chk-end"
                  className="form-input"
                  value={checkForm.endTime}
                  onChange={(e) =>
                    setCheckForm({ ...checkForm, endTime: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-outline btn-block"
              disabled={checking}
            >
              {checking ? 'Checking availability...' : 'Check Availability'}
            </button>
          </form>

          {checkResult && (
            <div
              className={`result-callout ${
                checkResult.available ? 'callout-available' : 'callout-unavailable'
              }`}
            >
              <div className="result-text-area">
                <span className="result-indicator">
                  {checkResult.available ? '✓ Available' : '✕ Unavailable'}
                </span>
                <p className="result-note">{checkResult.message}</p>
              </div>

              {checkResult.available && (
                <Link
                  to={`/book?instrumentId=${checkForm.instrumentId}&date=${checkForm.date}&startTime=${checkForm.startTime}&endTime=${checkForm.endTime}`}
                  className="btn btn-primary btn-sm btn-block mt-2"
                >
                  Book This Slot →
                </Link>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
