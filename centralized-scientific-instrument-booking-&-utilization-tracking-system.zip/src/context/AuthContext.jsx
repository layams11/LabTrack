import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const stored = localStorage.getItem('lab_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(() => {
    return localStorage.getItem('lab_token') || null;
  });

  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(true);

  // Validate session on app initialization
  useEffect(() => {
    let isMounted = true;

    const verifySession = async () => {
      const storedToken = localStorage.getItem('lab_token');
      if (!storedToken) {
        if (isMounted) setInitializing(false);
        return;
      }

      try {
        const res = await fetch('/api/auth/me', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${storedToken}`,
            'x-user-id': storedToken,
          },
        });

        if (res.ok) {
          const data = await res.json();
          if (isMounted && data.user) {
            setUser(data.user);
            localStorage.setItem('lab_user', JSON.stringify(data.user));
          }
        } else {
          // Token expired or invalid
          if (isMounted) {
            setUser(null);
            setToken(null);
            localStorage.removeItem('lab_user');
            localStorage.removeItem('lab_token');
          }
        }
      } catch (err) {
        console.warn('[AuthContext] Session verification error:', err);
      } finally {
        if (isMounted) setInitializing(false);
      }
    };

    verifySession();

    return () => {
      isMounted = false;
    };
  }, []);

  const signup = async (name, email, password, role = 'user') => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || 'Registration failed.');
      }

      setUser(data.user);
      setToken(data.token);
      localStorage.setItem('lab_user', JSON.stringify(data.user));
      localStorage.setItem('lab_token', data.token);

      return data.user;
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || 'Login failed. Please check your credentials.');
      }

      setUser(data.user);
      setToken(data.token);
      localStorage.setItem('lab_user', JSON.stringify(data.user));
      localStorage.setItem('lab_token', data.token);

      return data.user;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`,
          },
        });
      }
    } catch {
      // Ignore network errors on logout
    } finally {
      setUser(null);
      setToken(null);
      localStorage.removeItem('lab_user');
      localStorage.removeItem('lab_token');
    }
  };

  // Helper fetch that automatically injects auth token
  const authFetch = async (url, options = {}) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    };

    const currentToken = token || localStorage.getItem('lab_token');
    if (currentToken) {
      headers['Authorization'] = `Bearer ${currentToken}`;
      headers['x-user-id'] = currentToken;
    }

    const res = await fetch(url, {
      ...options,
      headers,
    });

    if (res.status === 401) {
      logout();
    }

    return res;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        initializing,
        signup,
        login,
        logout,
        authFetch,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
        isUser: user?.role === 'user',
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
