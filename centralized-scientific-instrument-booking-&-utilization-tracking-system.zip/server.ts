import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectDB } from './server/data/store.js';
import authRoutes from './server/routes/authRoutes.js';
import userRoutes from './server/routes/userRoutes.js';
import adminRoutes from './server/routes/adminRoutes.js';
import instrumentRoutes from './server/routes/instrumentRoutes.js';
import bookingRoutes from './server/routes/bookingRoutes.js';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(cors());
  app.use(express.json());

  // Initialize DB connection
  await connectDB(process.env.MONGO_URI);

  // Mount API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/user', userRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/instruments', instrumentRoutes);
  app.use('/api/bookings', bookingRoutes);

  app.get('/api/health', (req, res) => {
    res.json({
      status: 'online',
      project: 'Centralized Scientific Instrument Booking & Utilization Tracking System (2-Role Auth)',
      timestamp: new Date().toISOString(),
    });
  });

  // Mount Vite development server
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Centralized Scientific Instrument Booking server running on port ${PORT}`);
  });
}

startServer();
